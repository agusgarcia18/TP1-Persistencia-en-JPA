package utn.tp1.entidades;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cliente extends BaseEntidad{

    private String nombre;
    private String apellido;
    private String telefono;
    private String email;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "cliente_id") //FK llamada "cliente_id" en la tabla Pedidos
    @Builder.Default
    private List<Pedido> pedidos = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "cliente_id") //FK llamada "cliente_id" en la tabla Domicilio
    @Builder.Default
    private List<Domicilio> domicilios = new ArrayList<>();





    //Metodos
    public void agregarPedidos(Pedido pedido){
        pedidos.add(pedido);
    }
    public void agregarDomicilios(Domicilio domicilio) {domicilios.add(domicilio);}

    public void mostrarDomicilios(){
        for (Domicilio elemento:domicilios) {
            System.out.println("Calle : " + elemento.getCalle());
            System.out.println("Número :" + elemento.getNumero());
            System.out.println("Localidad :" + elemento.getLocalidad());
        }
    }

    public void mostrarPedidos(){
        for (Pedido elemento: pedidos) {
            if(elemento != null){
            System.out.println("Pedido numero: "+ elemento.getId());
            System.out.println("Fecha : " + elemento.getFecha());
            System.out.println("Estado :" + elemento.getEstado());
            System.out.println("------------------");
            elemento.getFactura().mostrarFactura(); //Llamamos al metodo de la clase Factura
            System.out.println("------------------");
        }
            else{
                System.out.println("El cliente "+nombre + "no ha realizado ningun pedido");
            }
        }
    }
}
