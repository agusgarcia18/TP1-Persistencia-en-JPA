package utn.tp1.enums;

public enum TipoEnvio {
    Delivery,
    Take_away

}
