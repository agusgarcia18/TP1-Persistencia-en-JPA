package utn.tp1.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import utn.tp1.entidades.Producto;

public interface ProductoRespository extends JpaRepository<Producto,Long> {
}
