package utn.tp1.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import utn.tp1.entidades.Factura;


public interface FacturaRepository extends JpaRepository<Factura, Long> {
}
