package utn.tp1.entidades;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.engine.internal.Cascade;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Data
public class Rubro extends BaseEntidad{

    private String denominacion;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "rubro_id")// FK llamada "rubro_id" en la tabla Producto
    @Builder.Default
    private List<Producto> productos = new ArrayList<>();

    public void agregarProductos(Producto producto){
        productos.add(producto);
    }


}
