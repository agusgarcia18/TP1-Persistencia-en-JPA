package utn.tp1.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import utn.tp1.entidades.Cliente;
public interface ClienteRepository extends JpaRepository <Cliente,Long> {
}
