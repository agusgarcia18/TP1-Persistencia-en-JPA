package utn.tp1.entidades;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.mapping.Set;
import utn.tp1.enums.TipoProducto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Producto extends BaseEntidad {

    private TipoProducto tipoProducto;
    private int tiempoEstimadoCocina;
    private String denominacion;
    private Double precioVenta;
    private Double precioCompra;
    private int stockActual;
    private int stockMinimo;
    private String unidadMedida;
    private String receta;

    @ManyToMany(mappedBy = "productos")
    @Builder.Default
    private List<Pedido> pedidos = new ArrayList<>();

    public void agregarPedido(Pedido pedido){
        pedidos.add(pedido);
    }

    public void mostrarProducto(){
        System.out.println("PRODUCTO: ");
        System.out.println("Denominacion");
    }







}
