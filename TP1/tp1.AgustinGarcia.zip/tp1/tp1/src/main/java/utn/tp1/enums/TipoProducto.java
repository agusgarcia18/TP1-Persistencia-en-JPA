package utn.tp1.enums;

public enum TipoProducto {

    Manufacturado,
    Insumo
}
