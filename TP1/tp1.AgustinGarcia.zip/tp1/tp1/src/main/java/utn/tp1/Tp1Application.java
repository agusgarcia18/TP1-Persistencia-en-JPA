package utn.tp1;
import utn.tp1.repositorios.*;
import utn.tp1.entidades.*;
import utn.tp1.enums.*;

import org.hibernate.Hibernate;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.text.SimpleDateFormat;
import java.util.Date;


@SpringBootApplication
public class Tp1Application {

	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	DomicilioRepository domicilioRepository;
	@Autowired
	PedidoRepository pedidoRepository;
	@Autowired
	FacturaRepository facturaRepository;
	@Autowired
	ProductoRespository productoRespository;
	@Autowired
	RubroRepository rubroRepository;

	public static void main(String[] args) {
		SpringApplication.run(Tp1Application.class, args);
	}

	@Bean
	CommandLineRunner init(ClienteRepository clienteRepo, DomicilioRepository domicilioRepo, PedidoRepository pedidoRepo, FacturaRepository facturaRepo, ProductoRespository productoRepo, RubroRepository rubroRepo) {
		return args -> {
			System.out.println("...SI FUNCIONO...");

			//Crear objeto cliente
			Cliente cliente= Cliente.builder()
					.nombre("Juan")
					.apellido("Pérez")
					.telefono("2634-775544")
					.email("juanperez@cliente.com")
					.build();

			//Crear objeto domicilio
			Domicilio domicilio = Domicilio.builder()
					.calle("Suipacha")
					.numero("30")
					.localidad("Ciudad")
					.build();

			Domicilio domicilio2 = Domicilio.builder()
					.calle("San Martin")
					.numero("345")
					.localidad("Ciudad")
					.build();

			// Asocio el domicilio al cliente
			cliente.agregarDomicilios(domicilio);
			cliente.agregarDomicilios(domicilio2);



			//Le damos forma al atributo fecha
			SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");
			String fecha1 = "09-12-2018";
			String fecha2 = "18-12-2022";

			//Parseo String en un objeto Date
			Date fechaUno= formatoFecha.parse(fecha1);
			Date fechaDos = formatoFecha.parse(fecha2);



			//Crear objeto producto
			Producto producto = Producto.builder()
					.denominacion("Hamburguesa")
					.precioVenta(2500.00)
					.precioCompra(1000.00)
					.receta("Pan, carne, queso y huevo")
					.stockActual(14)
					.stockMinimo(3)
					.tipoProducto(TipoProducto.Manufacturado)
					.tiempoEstimadoCocina(300)
					.unidadMedida("unidad")
					.build();

			Producto producto2 = Producto.builder()
					.denominacion("Carne")
					.precioVenta(1500.00)
					.precioCompra(300.00)
					.stockActual(3)
					.stockMinimo(3)
					.tipoProducto(TipoProducto.Insumo)
					.unidadMedida("Kg")
					.build();


			//Crear objetos rubro
			Rubro rubro = Rubro.builder()
					.denominacion("Comidas")
					.build();

			Rubro rubro2 = Rubro.builder()
					.denominacion("Materia Prima")
					.build();


			//Agregar un producto a un rubro
			rubro.agregarProductos(producto);
			rubro2.agregarProductos(producto2);

			//Guardar en la BD
			rubroRepository.save(rubro);
			rubroRepository.save(rubro2);


			//Crear objetos pedido
			Pedido pedido = Pedido.builder()
					.tipoEnvio(TipoEnvio.Delivery)
					.estado(Estado.Iniciado)
					.fecha(fechaUno)
					.total(3500.00)
					.build();

			//Asociar pedidos a clientes
			cliente.agregarPedidos(pedido);
			clienteRepository.save(cliente);

			//Agregar productos al pedido
			producto.agregarPedido(pedido);
			pedido.agregarProductos(producto);
			pedido.agregarProductos(producto2);


			//Crear objetos factura
			Factura factura = Factura.builder()
					.numero(25)
					.fecha(fechaUno)
					.descuento(10)
					.total(3150)
					.formaPago(FormaPago.Debito)
					.build();


			//Asociar la factura al pedido
			pedido.setFactura(factura);


			//Guardar Facturas en BD
			facturaRepository.save(factura);

			//Guardar el pedido en DB
			pedidoRepository.save(pedido);



			// Creo un nuevo objeto Cliente y asigno valores desde la base de datos
			Cliente clienteRecuperado = clienteRepository.findById(cliente.getId()).orElse(null);
			if (clienteRecuperado != null) {
				System.out.println("Nombre: " + clienteRecuperado.getNombre());
				System.out.println("Apellido: " + clienteRecuperado.getApellido());
				System.out.println("------------------");
				System.out.println("Domicilio del cliente: ");
				clienteRecuperado.mostrarDomicilios();
				System.out.println("------------------");
				clienteRecuperado.mostrarPedidos();
			}



		};
	}
}