package utn.tp1.entidades;

import jakarta.persistence.Entity;
import lombok.*;
@Entity
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class Domicilio extends BaseEntidad {
    private String calle;
    private String numero;
    private String localidad;


}
