package utn.tp1.entidades;

import jakarta.persistence.*;
import lombok.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import utn.tp1.enums.FormaPago;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Factura extends BaseEntidad {

    private int numero;
    private Date fecha;
    private double descuento;
    private FormaPago formaPago;
    private int total;

    public void mostrarFactura(){
        System.out.println("Factura numero: " + numero);
        System.out.println("Forma de pago: " + formaPago);
        System.out.println("Total a pagar: " + total);


    }
}




