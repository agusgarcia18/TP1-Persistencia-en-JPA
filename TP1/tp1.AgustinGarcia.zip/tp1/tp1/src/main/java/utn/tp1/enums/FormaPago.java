package utn.tp1.enums;

public enum FormaPago {
    Efectivo, Debito, Credito
}
