package utn.tp1.entidades;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.mapping.Set;
import utn.tp1.enums.Estado;
import utn.tp1.enums.TipoEnvio;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Pedido extends BaseEntidad {

    private Estado estado;
    private Date fecha;
    private TipoEnvio tipoEnvio;
    private double total;


    //Relacion 1a1 con Factura
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "factura_id") //FK "factura_id"
    private Factura factura;


    //Generacion de tabla intermedia "detallePedido" para la relacion N*M con la tabla Productos
    @ManyToMany(cascade = {
            CascadeType.PERSIST,
            CascadeType.MERGE})
    @JoinTable(
            name = "detallePedido",
            joinColumns = @JoinColumn (name = "pedido_id"),
            inverseJoinColumns = @JoinColumn(name = "producto_id")
    )
//Se pueden producir ERRORES DE RECURSIVIDAD por eso excluimos los metodos Equals and HashCode
    @EqualsAndHashCode.Exclude
//Si o si tenemos que colocar @Builder.Default sino da error
    @Builder.Default
    private List<Producto> productos = new ArrayList<>();

    public void agregarProductos(Producto producto){
        productos.add(producto);
    }



    }



