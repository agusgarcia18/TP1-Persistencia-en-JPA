package utn.tp1.enums;

public enum Estado {
    Iniciado,
    Preparacion,
    Entregado
}
